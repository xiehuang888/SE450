package shop.main;

import shop.ui.*;

class Exitstate implements State{

    Control control;
    private UIFormable _menus;

    Exitstate(Control control){
        this.control = control;
        add();
    }

    public UIFormable get_menus() {
        return _menus;
    }

    private void add(){

        UIBuildable m = UIBuildfactory.getUIBuilder();

        m.add("Default", new UIMenuAction() { public void run() {} });
        m.add("Yes",
                new UIMenuAction() {
                    public void run() {
                        control.setState(control.getExited());
                    }
                });
        m.add("No",
                new UIMenuAction() {
                    public void run() {
                        control.setState(control.getStart());
                    }
                });

        _menus = m.toUIMenu("Are you sure you want to exit?");
    }

}
