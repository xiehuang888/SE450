package shop.ui;

public interface UIMenuAction {
  void run();
}
