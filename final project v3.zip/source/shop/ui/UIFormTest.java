package shop.ui;

public interface UIFormTest {

  boolean run(String input);

}
