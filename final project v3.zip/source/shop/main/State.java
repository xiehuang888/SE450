package shop.main;

import shop.ui.UIFormable;

public interface State {
    public UIFormable get_menus();
}
