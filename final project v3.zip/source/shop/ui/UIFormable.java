package shop.ui;

public interface UIFormable {
    int size();
    String getHeading();
    String getPrompt(int i);
}
