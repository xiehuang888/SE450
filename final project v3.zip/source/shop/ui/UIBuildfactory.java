package shop.ui;

public class UIBuildfactory {

    static public UIBuilder getUIBuilder(){
        return new UIBuilder();
    }
}
