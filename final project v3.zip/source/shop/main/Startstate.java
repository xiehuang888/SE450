package shop.main;

import shop.ui.*;

class Startstate implements State{

    Control control;
    private UIFormable _menus;

    Startstate(Control control){

        this.control = control;
        add();
    }

    public UIFormable get_menus(){
        return this._menus;
    }

    private void add(){

        UIBuildable m = UIBuildfactory.getUIBuilder();
        new UIMenuActionEnum.prepare(control);

        m.add("Default",UIMenuActionEnum.DEFAULT.getUiMenuAction());
        m.add("Add/Remove copies of a video",UIMenuActionEnum.ADDREMOVE.getUiMenuAction());
        m.add("Check in a video",UIMenuActionEnum.CHECKIN.getUiMenuAction());
        m.add("Check out a video",UIMenuActionEnum.CHECKOUT.getUiMenuAction());
        m.add("Print the inventory",UIMenuActionEnum.PRINT.getUiMenuAction());
        m.add("Clear the inventory",UIMenuActionEnum.CLEAR.getUiMenuAction());
        m.add("Undo",UIMenuActionEnum.UNDO.getUiMenuAction());
        m.add("Redo",UIMenuActionEnum.REDO.getUiMenuAction());
        m.add("Print top ten all time rentals in order",UIMenuActionEnum.TOPTEN.getUiMenuAction());
        m.add("Exit",UIMenuActionEnum.EXIT.getUiMenuAction());
        m.add("Initialize with bogus contents",UIMenuActionEnum.INITIALIZE.getUiMenuAction());

        _menus = m.toUIMenu("Bob's Video");
    }

}
